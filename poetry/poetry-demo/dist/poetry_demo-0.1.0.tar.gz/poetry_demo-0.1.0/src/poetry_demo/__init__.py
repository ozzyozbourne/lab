print("Hello Seamen!")
